import java.util.Vector;
import java.awt.*;
import java.awt.event.*;
import javax.media.*;
import javax.media.format.*;
import javax.media.protocol.*;
import javax.media.datasink.*;

/**
 *
 * @author TW Burger from code by pawan_sin99
 */
public class VidCap 
{
    CaptureDeviceInfo device = null;
    MediaLocator ml = null;
    Player player = null;
    Component videoScreen = null;
    Processor processor = null;
    DataSink dataSink = null;
    TheDataSinkListener dataSinkListener = null;
    Vector deviceList;

    public VidCap() 
    {
        try 
        { //gets a list of devices how support the given video format
             deviceList = new Vector();
             deviceList = CaptureDeviceManager.getDeviceList(new YUVFormat());

            // get video device - the first one is almost always the only available camera
            device = (CaptureDeviceInfo) deviceList.firstElement();
            ml = device.getLocator();

            //create a source from the device
            String mediaFile = "vfw://0";
       
            MediaLocator mlr = new MediaLocator( mediaFile );

            //_player = Manager.createRealizedPlayer( mlr );
            DataSource ods = null;
            ods = Manager.createDataSource(mlr);

            // Clone the video source so it can be displayed and used to capture
            // the video at the same time. Trying to use the same source for two
            // purposes would cause a "source is in use" error
            DataSource cloneableDS = Manager.createCloneableDataSource(ods);
            DataSource PlayerVidDS = cloneableDS;

            // The video capture code will use the clone which is controlled by the player
            DataSource CaptureVidDS = 
              ((javax.media.protocol.SourceCloneable) cloneableDS).createClone();

            // -----------------------------------------------------------------
            // Display video
            // by starting the player on the source
            // clonable data source the clones are fed data
            // stopping the player will stop the video flow to the clone data source
            // -----------------------------------------------------------------

            player = Manager.createRealizedPlayer(PlayerVidDS);
            player.start();

            // get an audio device and create an audio data source
            deviceList = CaptureDeviceManager.getDeviceList(
                            new javax.media.format.AudioFormat(null));
            device = (CaptureDeviceInfo) deviceList.firstElement();
            ml = device.getLocator();
            DataSource audioDataSource = Manager.createDataSource(ml);

            // merge audio and video data sources
            // --------------------------
            DataSource mixedDataSource = null;
            DataSource dsArray[] = new DataSource[2];
            dsArray[0] = CaptureVidDS; // this is a cloned datasource
                                 // and is controlled by the master clonable data source
            dsArray[1] = audioDataSource;
            try 
            {
                mixedDataSource = javax.media.Manager.createMergingDataSource(dsArray);
            } 
            catch (Exception e) 
            {
            	System.out.println("erro 1");
                // your exception handling here
            }

            // setup output file format to msvideo
            FileTypeDescriptor outputType = 
                new FileTypeDescriptor(FileTypeDescriptor.MSVIDEO);

            // setup output video and audio data format
            Format outputFormat[] = new Format[2];
            //outputFormat[0] = new VideoFormat(VideoFormat.RGB);
            outputFormat[0] = new VideoFormat(VideoFormat.YUV);
            outputFormat[1] = new AudioFormat(AudioFormat.LINEAR);

            // ----------------------
            // create a new processor
            // ----------------------
            ProcessorModel processorModel = 
              new ProcessorModel(mixedDataSource, outputFormat, outputType);
            try {
                processor = Manager.createRealizedProcessor(processorModel);
            } catch (Exception e) {
            	System.out.println("erro 2");
                // your exception handling here
            }

            try {
                // get the output of the processor to be used as the datasink input 
                DataSource source = processor.getDataOutput();

                // create a File protocol MediaLocator with the location
                // of the file to which bits are to be written
                MediaLocator mediadestination = new MediaLocator("file:///c:/temp/vidcap.avi");

                // create a datasink to create the video file
                dataSink = Manager.createDataSink(source, mediadestination);
                
                // create a listener to control the datasink
                dataSinkListener = new TheDataSinkListener();
                dataSink.addDataSinkListener(dataSinkListener);
                dataSink.open();

                // now start the datasink and processor
                dataSink.start();

                processor.start();
            } catch (Exception e) {
            	System.out.println("erro 3");
                // your exception handling here
            }

            videoScreen = player.getVisualComponent();

            Frame frm = new Frame("Display of Webcam");
            frm.addWindowListener(new WindowAdapter() {

                @Override
                public void windowClosing(WindowEvent event) {
                    Frame f = (Frame) event.getSource();

                    // Stop the processor doing the movie capture first
                    processor.stop();
                    processor.close();

                    // Closing the processor will end the data stream to the data sink.
                    // Wait for the end of stream to occur before closing the datasink
                    dataSinkListener.waitEndOfStream(10);
                    dataSink.close();

                    // stop and close the player which closes the video data source
                    player.stop();
                    player.close();

                    //------------------------------------------------
                    // dispose of the frame and close the application
                    //------------------------------------------------
                    f.dispose();
                    System.exit(0);
                    //------------------------------------------------
                }
            });

            frm.setBounds(10, 10, 300, 300);
            frm.add(videoScreen);
            frm.setVisible(true);

        } 
        catch (Exception e) 
        {
            System.out.println("Aqui" + e.getMessage());
        }
    }
    
    public static void main(String[] args) 
    {

        // run a video capture object
        VidCap v = new VidCap();
    }
}

/**
 * Control the ending of the program prior to closing the data sink
 *
 */
class TheDataSinkListener implements DataSinkListener {

    boolean endOfStream = false;

    // Flag the ending of the data stream
    public void dataSinkUpdate(DataSinkEvent event) {
        if (event instanceof javax.media.datasink.EndOfStreamEvent) {
            endOfStream = true;
        }
    }

    /*Cause the current thread to sleep if the data stream is still available.
     * This makes certain that JMF threads are done prior
     * to closing the data sink and finalizing the output file
     */
    public void waitEndOfStream(long checkTimeMs) {
        while (!endOfStream) {
            try {
                //Thread.currentThread().sleep(checkTimeMs);
                Thread.sleep(checkTimeMs);
            } catch (InterruptedException ie) {
            	System.out.println("erro 4");
                // your exception handling here
            }
        }
    }
}