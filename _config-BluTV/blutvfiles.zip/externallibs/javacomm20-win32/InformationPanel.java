import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class InformationPanel extends JFrame
{
	private JPanel p = new JPanel(new BorderLayout());
	private JPanel localizado ;
	private Point localizacaoContainer,  localizaAnterior;
	private static Color cor;
	public final TransparentFrame frame = new TransparentFrame();
	private boolean moveFrame = false ;
	private boolean startTime = false ;
	public static boolean formaRetangulo = false;
	public boolean formaCirculo = false;
	
	public InformationPanel(int xPos, int yPos,
			                Point localizacaoContainernaTela, final Object localizadoSobre) throws Exception {
		
		//localizado = localizadoSobre;
		frame.setLayout(null);
		frame.getContentPane().add(p);
		cor = new Color(0.0f, 0.5f, 0.0f);
		if (xPos == 0 && yPos == 0) {
			frame.setBounds(xPos, yPos, 100, 100);
			frame.setVisible(false);
			frame.setAlwaysOnTop(true);
		} else
			frame.setBounds(xPos, yPos, 100, 100);
		
		frame.setVisible(true);
		frame.setAlwaysOnTop(true);
		//frame.setMaximizedBounds(new Rectangle(localizadoSobre.getBounds())) ;
		
		localizacaoContainer = localizacaoContainernaTela;		
	}
	
	public static void main(String[] args)
	{
		Point p = new Point();
		p.x = 50; p.y = 100;
		try
		{
			new InformationPanel(100,100,p,this);
		}
		catch(Exception erro)
		{
		}
	}
	
	
	
	
		
	class MyPanel extends JPanel {
		private static final long serialVersionUID = 1L;
		
		BufferedImage underFrameImg;
		
		int paintX = 0;
		
		int paintY = 0;
		
		public int X = 1;
		
		public MyPanel() {
			super();
			setOpaque(true);
			
		}
		
		public void paint(Graphics g) {
			super.paint(g);
			Graphics2D g2d = (Graphics2D) g;
			g2d.setColor(cor);
			
			g2d.setStroke(new BasicStroke(6.0f));
			if (InformationPanel.formaRetangulo) {
				g2d.draw(new Rectangle(5, 5, getSize().width - 10,
						getSize().height - 10));
				
			} else {
				g2d.drawOval(5, 5, getSize().width - 10, getSize().height - 10);
				
			}
			
		}
		
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.drawImage(underFrameImg, paintX, paintY, null);
			
		}
	}
	
	/**
	 * Dimensiona o TagSensor sobre o video
	 * 
	 * @param x  coordenada x do tagSensor sobre o v�deo
	 * @param y  coordenada y do tagSensor sobre o v�deo
	 * @param width largura do tagSensor sobre o v�deo
	 * @param height altura do tagSensor sobre o v�deo
	 */
	
	public void setPosition(int x, int y,  int width , int height,double percentual[]) {
		double x1 = 0 ; double y1 = 0 ; 
		double w1 = 0 ; double h1 = 0 ;
		if (x == 0 && y == 0) {
			frame.setVisible(false);
			return;
		}
		if(percentual[0] == 0.0 && percentual[1] == 0) // mesmo tamanho do v�deo
			frame.setBounds(x, y, width, height);
		else {
			if(percentual[0] > 0) // diminui em rela��o ao original ent�o subtrai
			{
				x1 =  x - (x * percentual[0]) ;
				w1 = width - (width * percentual[0]) ;
			}
			else {
				x1 = x + (x * percentual[0]) ;
				w1 = width + (width * percentual[0]) ;
			}
			
			if(percentual[1] > 0) {
				h1 = height - (height * percentual[1]) ; 
				y1 = y - (y * percentual[1]) ;
			}
			else {
				h1 = height + (height * percentual[1]) ; 
				y1 =  y + (y * percentual[1]) ;
			}
			
			System.out.println("x1 = " + (int) x1 + " y1 = " + (int) y1) ;
			
			x1 = (x1 + localizacaoContainer.x)  ;
			y1 = (y1 + localizacaoContainer.y);
			
			
			frame.setBounds((int) x - localizacaoContainer.x, (int) y - localizacaoContainer.y, (int) w1, (int) h1);
		}
		frame.setVisible(true);
		
	}
	
	/**
	 * Alternar entre vis�vel e n�o vis�vel o tagSensor
	 * 
	 * @param b <code>boolean</code> se verdadeiro exibe o frame
	 */
	public void setVisible(boolean b) {
		frame.setVisible(b);
	}
	
	
	
	/**
	 * Verifica se o tagSensor encontra v�sivel sobre o v�deo
	 * @return <code>boolean</code> se o tagSensor esta visivel
	 */
	public boolean isVisible() {
		return (frame.isVisible());
	}
	
	
	/**
	 * Calcula as posi��es X e Y do tagSensor sobre o v�deo.
	 * @return <code>Point</code> representa as coordenadas de X e Y.
	 */
	private Point calculaXY() {
		Point p1 = new Point();
		int xPosicaoRelativa, yPosicaoRelativa;
		// 5 referente a borda da JFrame
		xPosicaoRelativa = ((int) frame.getLocationOnScreen().getX()
				- localizacaoContainer.x - 5);
		;
		// 27 referente a largura da barra de titulo
		yPosicaoRelativa = ((int) frame.getLocationOnScreen().getY()- localizacaoContainer.y + 27);
		
		p1.x = xPosicaoRelativa;
		p1.y = yPosicaoRelativa;
		return (p1);
		
	}
	
	/**
	 * Captura a Coordenada X e Y do TagSensor sobre o v�deo
	 * @return <code>Point</code> onde o TagSensor se posiciona sobre o v�deo.
	 */
	public Point getPointXY() {
		return (calculaXY());
	}
	
	/**
	 * Captura a Altura e Largura do tagSensor sobre o v�deo
	 * @return <code>Point</code> informando a altura e largura do tagSensor.
	 */
	public Point getPointHeightWidth() {
		Point tamanho = new Point();
		tamanho.y = frame.getHeight();
		tamanho.x = frame.getWidth();
		return (tamanho);
	}
	
	/**
	 * Retorna a cor do tagSensor 
	 * @return <code>Color</code> representa a cor do tagSensor
	 */
	public Color getColorTagSensor() {
		return (cor) ;
	}	
		
	/**
	 * Captura a largura e altura do container onde o player JMF esta
	 * colado.
	 * @return <Point> informando width e height
	 */
	public Point getPlayerDimension() {
		Point p2 = new Point() ;
		p2.x = localizado.getWidth() ;
		p2.y = localizado.getHeight() ;
		return(p2) ;
	}	   

	
	/**
	 * Calcula a posi��o do tagSensor de acordo com o tamanho do player onde esta
	 * atualmente sendo exibido o v�deo. Se o valor retornado for negativo � porque
	 * o player atual � maior do que o player usado para criar os tagSensors.
	 * @param containerPlayer informa o componente onde o player JMF foi inserido.
	 * @param origemTagSensor informa as posi��es quando o sensor foi criado.
	 * @return <code>double[]</code> contendo os percentuais de aumento ou diminui��o do player.
	 */
	public double[] calculaNovoTagSensor(Component containerPlayer,Point origemTagSensor) {
		double x = 0 ; double y = 0 ;
		double retorn[] = new double[2] ;
		// calcula quantos % o player atual � maior ou menor que o player
		// utilizado na cria��o do tagSensor.
		
		// player original = origemTagSensor
		// player atual = containerPlayer 
		
		x = 1 - ( containerPlayer.getWidth() / origemTagSensor.getX() ) ;
		y = 1 - ( containerPlayer.getHeight() / origemTagSensor.getY() ) ;
		
		retorn[0] = x ; retorn[1] = y ;
		
		return(retorn) ;
	}
	
}
