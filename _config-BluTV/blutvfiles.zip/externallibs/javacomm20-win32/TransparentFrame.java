import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

class TransparentFrame extends JFrame 
{
	private static final long serialVersionUID = 1L;
	public static Color cor;
	Robot robot;
	BufferedImage screenImg;
	Rectangle screenRect;
	SpecificPanel contentPanel;
	boolean userActivate = false;
	public static String forma;
	public static JLabel mensagem = new JLabel("mens");
		
	/**
	 * Construtor do TagSensor inicializa as variaveis e atualiza a
	 * transpar�ncia
	 * 
	 */
	public TransparentFrame(int x, int y, int width, int height) 
	{		
		createScreenImage();
		cor = new Color(0.0f, 0.5f, 0.0f);
		contentPanel = new SpecificPanel(cor);
		setBounds(x,y,width,height);
		setFormatoFrame("rectangle");
		setColorFrame("0,0,255");
		setContentPane(contentPanel);
		getContentPane().setLayout(null);
		mensagem.setBounds(10,10,100,25);
		getContentPane().add(mensagem);
		setUndecorated(true);
		setVisible(true);
		setAlwaysOnTop(true);		
		
		setVisible(false);
		createScreenImage();
		setVisible(true);
		resetUnderImg();							
		
	}
	
	public static void main(String[] args)
	{
		TransparentFrame t = new TransparentFrame(10,10,100,100);
	}
	
	private void createScreenImage() 
	{
		try 
		{
			if (robot == null)
				robot = new Robot();
		} 
		catch (AWTException ex) 
		{
			ex.printStackTrace();
		}
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		screenRect = new Rectangle(0, 0, screenSize.width, screenSize.height);
		screenImg = robot.createScreenCapture(screenRect);		
	}
						
	/**
	 * define o formato do tagSensor (Circulo ou Retangulo).
	 * @param formato String informando se o formato � Circulo ou Retangulo.
	 */
	public void setFormatoFrame(String formato) 
	{
		if (formato.equals("rectangle"))
		    forma = "rectangle";
		if (formato.equals("circle"))
		    forma = "circle"; 
		if (formato.equals("roundrect"))
		    forma = "roundrect";    
	}		
	
		
	/**
	 * Separa as cores em RGB e muda a cor do TagSensor
	 * @param color Objeto contendo a cor em formato RGB
	 */
	public void setColorFrame(Object color) 
	{
		String corTemp = color.toString() ;
		String tempCor = "" ;
		int iContador = 0 ;
		int red = 0 , green = 0 , blue = 0 ;
		int posicao = 0 ;
		
		try 
		{
			while(corTemp.length() >= iContador) 
			{				
				if(corTemp.charAt(iContador) == ',') 
				{
					posicao++ ;
					iContador++ ;
					try 
					{
						if (posicao == 1)
							red = Integer.parseInt(tempCor) ;
						else if(posicao == 2)
							    green = Integer.parseInt(tempCor) ;
						     else if(posicao == 3)
							         blue = Integer.parseInt(tempCor) ;
					}
					catch(NumberFormatException number) 
					{
						System.out.println("Number Format Error") ;
					}
					
					tempCor = "" ;
				}
				
				tempCor += corTemp.charAt(iContador) ;
				iContador++ ;   
			}
		}
		catch(IndexOutOfBoundsException e) 
		{
			if(posicao == 3) 
			{
				try 
				{
					blue = Integer.parseInt(tempCor);
				}
				catch(NumberFormatException n) 
				{
					return;
				}   
			}   
		}
		
		cor = new Color(red,green,blue);		
	}
	
	private void resetUnderImg() 
	{
		if (robot != null && screenImg != null) 
		{
			Rectangle frameRect = getBounds();
			int x = frameRect.x;
			contentPanel.paintX = 0;
			contentPanel.paintY = 0;
			if (x < 0) 
			{
				contentPanel.paintX = -x;
				x = 0;
			}
			
			int y = frameRect.y;
			if (y < 0) 
			{
				contentPanel.paintY = -y;
				y = 0;
			}
			
			int w = frameRect.width;
			if (x + w > screenImg.getWidth())
				w = screenImg.getWidth() - x;
			
			int h = frameRect.height;
			if (y + h > screenImg.getHeight())
				h = screenImg.getHeight() - y;
			contentPanel.underFrameImg = screenImg.getSubimage(x, y, w, h);			
		}
	}
}

class SpecificPanel extends JPanel 
{
	private static final long serialVersionUID = 1L;
	BufferedImage underFrameImg;
	int paintX = 0;
	int paintY = 0;
	public int X = 1;
	private static Color cor;
	
	public SpecificPanel(Color cor) 
	{
		super();
		setOpaque(true);
		this.cor = cor;		
	}
	
	public void paint(Graphics g) 
	{
		super.paint(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(this.cor);
		
		g2d.setStroke(new BasicStroke(6.0f));
		if (TransparentFrame.forma.equals("rectangle")) 
		{
			g2d.draw(new Rectangle(5, 5, getSize().width - 10, getSize().height - 10));			
		} 
		if (TransparentFrame.forma.equals("circle"))  
		{
			g2d.drawOval(5, 5, getSize().width - 10, getSize().height - 10);			
		}		
		if (TransparentFrame.forma.equals("roundrect"))  
		{
			g2d.drawRoundRect(5, 5, getSize().width - 10, getSize().height - 10, 10, 10);			
		}	
	}
	
	protected void paintComponent(Graphics g) 
	{
		super.paintComponent(g);
		g.drawImage(underFrameImg, paintX, paintY, null);		
	}
}