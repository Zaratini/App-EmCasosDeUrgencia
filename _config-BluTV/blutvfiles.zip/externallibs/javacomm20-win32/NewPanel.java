import java.awt.*;
import javax.swing.*;

class NewComponent extends JPanel 
{
	private static final String FORM1 = "rectangle";
	private static final String FORM2 = "roundrect";
	private static final String FORM3 = "circle";
	
	private static final long serialVersionUID = 1L;
	int paintX = 0;
	int paintY = 0;
	private static Color color;
	private static String form = this.FORM1;
	private static int x,y,w,h;
	
	public NewComponent(int x, int y, int width, int height, Color color, String form) 
	{
		super();
		setOpaque(true);
		this.color = color;
		this.x = x;
		this.y = y;
		this.w = width;
		this.h = height;
		this.form = form;
	}
	
	public void paint(Graphics graphics) 
	{
		super.paint(graphics);
		Graphics2D graphics2D = (Graphics2D) graphics;
		graphics2D.setColor(this.color);		
		graphics2D.setStroke(new BasicStroke(2.0f));		
		
		if (this.form.equals(this.FORM1)) 
			graphics2D.draw(new Rectangle(this.x, this.y, this.w, this.h));			
		
		if (this.form.equals(this.FORM2)) 
			graphics2D.drawOval(this.x, this.y, this.w, this.h);			
		
		if (this.form.equals(this.FORM3)) 
			graphics2D.drawRoundRect(this.x, this.y, this.w, this.h, 10, 10);			
	}
}

public class NewPanel extends JFrame
{
	NewComponent painel;
	
	public NewPanel()
	{
		setBounds(100,100,200,200);
		getContentPane().setBackground(Color.blue);		
		painel = new NewComponent(5,5,50,50,Color.red, NewComponent.FORM2);	
		getContentPane().add(painel);
	}
	
	public static void main(String argumentos[])
	{
		JFrame aplicacao = new NewPanel();
		aplicacao.setVisible(true);
	}
}

